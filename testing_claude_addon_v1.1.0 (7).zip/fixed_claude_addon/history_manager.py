"""
History management utilities for the Blender Claude addon
"""
import logging
import os
import time
from datetime import datetime

# Setup logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# Check if we're running inside Blender
try:
    import bpy
    BLENDER_AVAILABLE = True
except ImportError:
    BLENDER_AVAILABLE = False
    logger.warning("Running outside of Blender environment")

def get_history_dir(context=None):
    """Get the directory where history archives are stored, creating it if needed"""
    # Ensure directory exists even with a custom path
    default_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "history")
    
    # Always make sure the default directory exists first as a fallback
    if not os.path.exists(default_dir):
        try:
            os.makedirs(default_dir, exist_ok=True)
            logger.info(f"Created default history directory: {default_dir}")
        except Exception as e:
            logger.error(f"Failed to create default history directory: {str(e)}")
    
    # If we're not in Blender or don't have context, use the default
    if not BLENDER_AVAILABLE or not context:
        return default_dir
    
    # Try to get the custom directory from preferences
    try:
        # Get the addon preferences
        addon_prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        # Check if there's a custom location defined
        if addon_prefs.archive_location and addon_prefs.archive_location.strip():
            history_dir = addon_prefs.archive_location
            logger.info(f"Using custom history directory: {history_dir}")
            
            # Create the custom directory if needed
            if not os.path.exists(history_dir):
                try:
                    os.makedirs(history_dir, exist_ok=True)
                    logger.info(f"Created custom history directory: {history_dir}")
                except Exception as e:
                    logger.error(f"Failed to create custom history directory: {str(e)}")
                    return default_dir  # Fall back to default if we can't create custom
            
            return history_dir
        else:
            # Use the default directory if no custom path
            logger.info(f"No custom path specified, using default history directory: {default_dir}")
            return default_dir
    except Exception as e:
        # If anything fails, use the default directory
        logger.error(f"Error accessing preferences, using default directory: {str(e)}")
        return default_dir

def archive_conversation(context=None):
    """Archive the current conversation to a text file"""
    if not BLENDER_AVAILABLE or not context:
        logger.warning("Cannot archive conversation outside of Blender")
        return False
    
    try:
        # Get the history directory
        history_dir = get_history_dir(context)
        if not history_dir:
            return False
        
        # Get the conversation from the scene
        conversation = context.scene.claude_conversation
        
        # If there's nothing to archive, return early
        if len(conversation) == 0:
            return True
        
        # Generate a filename based on the current time
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"claude_conversation_{timestamp}.txt"
        filepath = os.path.join(history_dir, filename)
        
        # Write the conversation to the file
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"Claude Conversation - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 60 + "\n\n")
            
            for item in conversation:
                # Write question with timestamp if available
                if hasattr(item, "timestamp") and item.timestamp:
                    f.write(f"YOU ({item.timestamp}):\n")
                else:
                    f.write("YOU:\n")
                
                f.write(f"{item.question}\n\n")
                
                # Note if there was an image
                if hasattr(item, "image_path") and item.image_path:
                    f.write(f"[Screenshot included: {item.image_path}]\n\n")
                
                # Write answer
                f.write("CLAUDE:\n")
                f.write(f"{item.answer}\n\n")
                
                # Add separator
                f.write("-" * 60 + "\n\n")
        
        logger.info(f"Archived conversation to {filepath}")
        return True
    
    except Exception as e:
        logger.error(f"Error archiving conversation: {e}")
        return False

def open_history_file():
    """Open the history directory"""
    try:
        history_dir = get_history_dir()
        
        if not history_dir or not os.path.exists(history_dir):
            logger.error(f"History directory not found: {history_dir}")
            return False
        
        # Use the appropriate command to open the directory based on platform
        import platform
        import subprocess
        
        if platform.system() == "Windows":
            os.startfile(history_dir)
        elif platform.system() == "Darwin":  # macOS
            subprocess.Popen(["open", history_dir])
        else:  # Linux
            subprocess.Popen(["xdg-open", history_dir])
        
        return True
    
    except Exception as e:
        logger.error(f"Error opening history directory: {e}")
        return False

if __name__ == "__main__":
    # Test functionality when run directly
    if BLENDER_AVAILABLE:
        print(f"History directory: {get_history_dir(bpy.context)}")
    else:
        print(f"History directory: {get_history_dir()}")
