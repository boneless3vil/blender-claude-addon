"""
API module for the Blender Claude addon
Handles communication with Anthropic's Claude API
"""
import logging
import json
import random
import re
import time
import os
import base64
import requests
from datetime import datetime

# Setup logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.WARNING)  # Only show warnings and errors, not info messages
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# Define a flag for whether Anthropic module is available
ANTHROPIC_AVAILABLE = False

# Function to attempt adding site-packages to path
def add_site_packages_to_path():
    """Try to add user site-packages to sys.path if possible"""
    import sys
    import site
    
    try:
        # Get user site-packages directory
        user_site = site.getusersitepackages()
        if user_site not in sys.path:
            sys.path.append(user_site)
            logger.info(f"Added user site-packages to path: {user_site}")
            return True
    except Exception as e:
        logger.warning(f"Failed to add user site-packages: {str(e)}")
    
    return False

# Check if the Anthropic module is available
try:
    # Try to import from the vendor directory first (should already be in sys.path from __init__.py)
    import anthropic
    ANTHROPIC_AVAILABLE = True
    logger.info("Anthropic API module loaded successfully from vendor directory")
except ImportError:
    # Vendor import failed, try user site-packages
    added_path = add_site_packages_to_path()
    
    # Try importing again from user site-packages
    if added_path:
        try:
            import anthropic
            ANTHROPIC_AVAILABLE = True
            logger.info("Anthropic API module loaded from user site-packages")
        except ImportError:
            logger.warning("Anthropic API module not found in vendor packages or site-packages")
            
            # Create a placeholder anthropic module for type checking
            class AnthropicPlaceholder:
                class Anthropic:
                    def __init__(self, api_key=None):
                        pass
                        
                    class messages:
                        @staticmethod
                        def create(*args, **kwargs):
                            return None
            
            # This allows the code to pass static type checking
            anthropic = AnthropicPlaceholder()
            logger.warning("Using REST API fallback mode")
    else:
        # Create a placeholder anthropic module for type checking
        class AnthropicPlaceholder:
            class Anthropic:
                def __init__(self, api_key=None):
                    pass
                    
                class messages:
                    @staticmethod
                    def create(*args, **kwargs):
                        return None
        
        # This allows the code to pass static type checking
        anthropic = AnthropicPlaceholder()
        logger.warning("Using REST API fallback mode")

def get_demo_response(prompt):
    """Generate a demo response without using the API"""
    # Short delay to simulate API call
    time.sleep(1)
    
    # Collection of witty demo responses for different query types
    demo_responses = {
        "model": [
            "[Demo Mode] I'd recommend adding a Subdivision Surface modifier to smooth out those edges. Your mesh could use a bit more geometry for better deformation.",
            "[Demo Mode] The topology on your model looks clean! For animation, I suggest adding edge loops near the joints for better deformation.",
            "[Demo Mode] Your model has some n-gons that might cause issues when subdivided. Try using quads throughout for best results.",
            "[Demo Mode] Consider using a mirror modifier for symmetrical models - it'll save you time and ensure perfect symmetry.",
        ],
        "rendering": [
            "[Demo Mode] For realistic materials, try using the Principled BSDF shader with roughness around 0.2 and a subtle normal map.",
            "[Demo Mode] Your lighting setup could use a three-point approach: key light, fill light, and rim light to really make your model pop.",
            "[Demo Mode] For better glass materials, make sure your IOR is set to 1.45 and transmission to 1.0, with a very slight roughness.",
            "[Demo Mode] Try adding an HDRI environment map for more realistic reflections and ambient lighting.",
        ],
        "animation": [
            "[Demo Mode] Remember to use the Graph Editor to smooth out your keyframes with Bézier curves for more natural motion.",
            "[Demo Mode] For character animation, always start with the major poses (extremes) before adding breakdowns and inbetweens.",
            "[Demo Mode] Your walk cycle could use more overlap and follow-through in the arms and head for a natural feel.",
            "[Demo Mode] Add some anticipation before that jump action - it'll make the movement more believable and impactful.",
        ],
        "general": [
            "[Demo Mode] I see what you're trying to do there! In Blender 4.0+, you can achieve that more easily by using geometry nodes.",
            "[Demo Mode] Have you tried using the new asset browser? It would make reusing your materials and objects much easier for this project.",
            "[Demo Mode] For better performance with heavy scenes, try using linked libraries for assets you reuse frequently.",
            "[Demo Mode] You might want to check out the Rigify add-on for character rigging - it'll save you hours of setup time!",
        ],
        "help": [
            "[Demo Mode] To activate this feature for real, enter your Anthropic API key in the add-on preferences panel. Claude can help with specific Blender questions and even analyze screenshots of your work!",
            "[Demo Mode] I'm currently running in demo mode. For full Claude functionality, you'll need an Anthropic API key (starting with 'sk-ant-'). Enter it in the add-on preferences.",
            "[Demo Mode] This is a preview of Claude's capabilities. With a valid API key, I can provide specific advice about your scene and help troubleshoot issues.",
            "[Demo Mode] For personalized responses, add your API key in the preferences. Claude can analyze your specific Blender setup and provide tailored advice.",
        ],
        "screenshot": [
            "[Demo Mode] I can see your screenshot! With a valid API key, Claude would analyze what's in your 3D view and provide specific feedback on your models, materials, and scene setup.",
            "[Demo Mode] In screenshot mode with a valid API key, I'd be able to point out specific areas for improvement in your viewport and suggest relevant techniques.",
            "[Demo Mode] Screenshot captured! With an Anthropic API key, Claude would examine your Blender workspace and give you customized advice about what you're working on.",
            "[Demo Mode] I see your Blender viewport! When using a valid API key, Claude can analyze the contents of your screen to give contextual assistance with your specific project.",
        ]
    }
    
    # Determine which category of response to use based on keywords in the prompt
    category = "general"
    
    lower_prompt = prompt.lower()
    if any(word in lower_prompt for word in ["model", "mesh", "topology", "vertex", "vertices", "edge", "face", "polygon", "geometry"]):
        category = "model"
    elif any(word in lower_prompt for word in ["render", "material", "shader", "light", "shadow", "texture", "bsdf", "cycles", "eevee"]):
        category = "rendering"
    elif any(word in lower_prompt for word in ["animate", "animation", "keyframe", "rig", "armature", "bone", "pose", "motion"]):
        category = "animation"
    elif any(word in lower_prompt for word in ["help", "assist", "how do", "api key", "not working"]):
        category = "help"
    elif any(word in lower_prompt for word in ["screenshot", "image", "picture", "photo", "capture", "see"]) or "[Screenshot]" in prompt:
        category = "screenshot"
    
    # Select a random response from the appropriate category
    return random.choice(demo_responses[category])

def validate_api_key(api_key):
    """
    Validate the format of an Anthropic API key with detailed feedback
    Returns tuple of (is_valid, message)
    """
    if not api_key:
        return False, "API key cannot be empty"
    
    # Strip any whitespace that might have been accidentally copied
    api_key = api_key.strip()
    
    # Very minimal validation - just check the prefix and length
    # We want to be extremely permissive since API keys can have various formats
    if not api_key.startswith("sk-ant-"):
        # Additional check for new API key format that might start with "sk-"
        if api_key.startswith("sk-") and len(api_key) >= 30:
            logger.info("Key starts with 'sk-' but not 'sk-ant-', allowing it for testing with the API")
            # Continue with validation even though it doesn't match expected prefix
        else:
            return False, "Invalid API key format. Anthropic API keys typically start with 'sk-ant-'"
    elif len(api_key) < 30:  # Minimum expected length
        return False, "API key is too short. Check that you've copied the entire key"
    
    # Remove any character validation since it's causing false rejections
    # Some valid API keys may contain characters that we incorrectly flagged as invalid
    # We'll let the API server determine if the key is valid
    
    # Pass any key that meets the basic prefix and length requirements
    # Let the actual API server determine if it's valid or not
    
    # Try to make a simple test request to the Anthropic API
    try:
        # Basic format is valid, try a minimal API call to check if it's active
        headers = {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json"
        }
        
        # Use a minimal payload just to test authentication
        test_payload = {
            "model": "claude-3-haiku-20240307",  # Use the smallest/fastest model for testing
            "max_tokens": 10,
            "messages": [
                {"role": "user", "content": "Test"}
            ]
        }
        
        # Very short timeout to avoid long waits
        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers=headers,
            json=test_payload,
            timeout=10  # Increased from 5 to 10 seconds for more reliable testing
        )
        
        # Check response status
        if response.status_code == 200:
            return True, "API key is valid and working correctly"
        else:
            # Parse the error response
            try:
                content_type = response.headers.get('content-type', '')
                
                # Check if response is HTML instead of JSON
                if 'text/html' in content_type or response.text.strip().startswith(('<!DOCTYPE', '<html')):
                    logger.error(f"Received HTML response instead of JSON during API key validation")
                    
                    # Attempt to diagnose HTML response cases
                    if "captive portal" in response.text.lower() or "login" in response.text.lower():
                        return False, "Network issue detected: You may be behind a captive portal or corporate proxy that's intercepting API requests"
                    elif "api key" in response.text.lower() or "authentication" in response.text.lower():
                        return False, "Authentication error: The API rejected your key or you may be experiencing a network issue"
                    else:
                        return False, "Unexpected HTML response from API. This could indicate a network issue or proxy problem"
                
                # Handle normal JSON responses
                elif 'application/json' in content_type:
                    try:
                        error_data = response.json()
                        error_type = error_data.get("error", {}).get("type", "unknown")
                        error_message = error_data.get("error", {}).get("message", "Unknown error")
                        
                        if error_type == "authentication_error" or response.status_code == 401:
                            if "invalid" in error_message.lower() and "api" in error_message.lower():
                                return False, "Invalid API key: The key was rejected by Anthropic's server"
                            elif "expired" in error_message.lower():
                                return False, "Expired API key: Your key has expired. Please generate a new one"
                            else:
                                return False, f"Authentication error: {error_message}"
                                
                        elif error_type == "rate_limit_error" or response.status_code == 429:
                            # If we hit rate limits, the key is valid but we're using it too much
                            return True, "API key is valid, but you've reached your rate limit. Wait a bit before making more requests"
                            
                        elif error_type == "invalid_request_error" or response.status_code == 400:
                            # If it's a bad request but not an auth error, the key itself might be valid
                            return True, "API key format seems valid, but there was an issue with the request"
                            
                        else:
                            return False, f"API key test failed: {error_type} - {error_message}"
                    except json.JSONDecodeError:
                        return False, f"Error parsing API response: Invalid JSON received with application/json content type"
                else:
                    return False, f"API key test failed: Unexpected content type '{content_type}' - HTTP {response.status_code}"
            except json.JSONDecodeError as json_err:
                # Specific handling for JSON parsing errors
                if response.text.strip().startswith(('<!DOCTYPE', '<html')):
                    return False, "Received HTML instead of JSON. This usually indicates a network issue or proxy interference"
                else:
                    return False, f"JSON parsing error: {str(json_err)}"
            except Exception as err:
                return False, f"API key test failed: HTTP {response.status_code} - {str(err)}"
    except Exception as e:
        # Network error or timeout
        logger.error(f"Error testing API key: {str(e)}")
        # Since we couldn't connect, we can only validate the format
        return True, "API key format is valid, but couldn't verify with Anthropic servers. Check your internet connection"
    
    return True, "API key format appears valid"

def ask_claude(prompt, api_key="", model="claude-3-opus-20240229", use_demo_mode=False, max_retries=2):
    """Send a prompt to Claude and get a response"""
    # Use demo mode if enabled or if no API key is provided
    if use_demo_mode or not api_key:
        return get_demo_response(prompt)
        
    # Add retry logic
    retries = 0
    
    try:
        # Check if the Anthropic module is available
        if ANTHROPIC_AVAILABLE:
            # Use the anthropic module
            logger.info("Using Anthropic Python module for API communication")
            client = anthropic.Anthropic(api_key=api_key)
            
            # Call the API
            message = client.messages.create(
                model=model,
                max_tokens=1024,
                temperature=0.7,
                system="""You are Claude, an AI assistant created by Anthropic, integrated into Blender as a helpful addon. You're an expert in 3D modeling, animation, rendering, and all aspects of Blender. Give concise, practical advice to help users with their Blender projects. Explain complex concepts clearly and provide step-by-step instructions when needed.
                
When providing code examples, you can use special highlighting markers to emphasize important parts:
1. For moderately important code lines, prefix them with '# HIGHLIGHT:' for Python or '// HIGHLIGHT:' for other languages
2. For critically important code lines, prefix them with '# IMPORTANT:' or '// IMPORTANT:'

These highlighted sections will be visually emphasized in the Blender interface. Use this feature to draw attention to the most important parts of your code examples. For example:

```python
import bpy

# HIGHLIGHT: Set up the default cube with a subdivision modifier
cube = bpy.context.object
modifier = cube.modifiers.new(name="Subdivision", type='SUBSURF')

# IMPORTANT: Always set viewport levels to match render levels
modifier.levels = 2
modifier.render_levels = 2

# The rest of the code continues normally
cube.scale = (1.2, 1.2, 1.2)
```
                """,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            
            if message and hasattr(message, 'content') and len(message.content) > 0:
                return message.content[0].text
            else:
                return "Error: Could not get response from Claude API"
        
        else:
            # Fallback to direct API call
            logger.info("Using REST API fallback mode for Anthropic API communication")
            logger.info("For better performance, consider installing the anthropic package in Blender's Python environment")
            
            # Check if we have a screenshot in the prompt and add a note about it
            if "[Screenshot]" in prompt:
                logger.info("Processing screenshot in fallback mode (may be slower)")
                
            # A note that we're using the fallback mode can be added to the prompt
            modified_prompt = prompt
            
            headers = {
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json"
            }
            
            data = {
                "model": model,
                "max_tokens": 1024,
                "temperature": 0.7,
                "system": """You are Claude, an AI assistant created by Anthropic, integrated into Blender as a helpful addon. You're an expert in 3D modeling, animation, rendering, and all aspects of Blender. Give concise, practical advice to help users with their Blender projects. Explain complex concepts clearly and provide step-by-step instructions when needed.
                
When providing code examples, you can use special highlighting markers to emphasize important parts:
1. For moderately important code lines, prefix them with '# HIGHLIGHT:' for Python or '// HIGHLIGHT:' for other languages
2. For critically important code lines, prefix them with '# IMPORTANT:' or '// IMPORTANT:'

These highlighted sections will be visually emphasized in the Blender interface. Use this feature to draw attention to the most important parts of your code examples. For example:

```python
import bpy

# HIGHLIGHT: Set up the default cube with a subdivision modifier
cube = bpy.context.object
modifier = cube.modifiers.new(name="Subdivision", type='SUBSURF')

# IMPORTANT: Always set viewport levels to match render levels
modifier.levels = 2
modifier.render_levels = 2

# The rest of the code continues normally
cube.scale = (1.2, 1.2, 1.2)
```
                """,
                "messages": [
                    {"role": "user", "content": prompt}
                ]
            }
            
            # Retry logic for network issues
            while True:
                try:
                    # Add a reasonable timeout to prevent hanging
                    response = requests.post(
                        "https://api.anthropic.com/v1/messages",
                        headers=headers,
                        json=data,
                        timeout=30  # 30 second timeout should be plenty for the API to respond
                    )
                    break  # If request succeeds, exit the retry loop
                except (requests.exceptions.Timeout, 
                        requests.exceptions.ConnectionError, 
                        requests.exceptions.RequestException) as err:
                    # Only retry for network-related errors
                    if retries < max_retries:
                        retries += 1
                        logger.warning(f"API request failed, retrying ({retries}/{max_retries}): {err}")
                        time.sleep(2)  # Wait before retrying
                    else:
                        logger.error(f"Max retries reached. Last error: {err}")
                        raise Exception(f"Network error after {max_retries} retries: {err}")
            
            # Check if the request was successful
            if response.status_code == 200:
                result = response.json()
                return result["content"][0]["text"]
            else:
                # Handle API error with more specific messages
                try:
                    content_type = response.headers.get('content-type', '')
                    
                    # Check if content is HTML instead of JSON (common with proxy issues or redirects)
                    if 'text/html' in content_type or response.text.strip().startswith(('<!DOCTYPE', '<html')):
                        # Special handling for HTML responses which might indicate network issues
                        if "captive portal" in response.text.lower() or "login" in response.text.lower():
                            logger.error("Received HTML login page instead of API response - possible captive portal or network issue")
                            raise Exception("Network issue detected: Received HTML login page instead of API response. You may be behind a captive portal or corporate proxy.")
                        elif "api key" in response.text.lower() or "authentication" in response.text.lower():
                            logger.error("Received HTML error page mentioning API key or authentication")
                            raise Exception("Authentication error: The API rejected your key. Please verify your Anthropic API key and try again.")
                        else:
                            logger.error(f"Received HTML instead of JSON response: {response.text[:300]}...")
                            raise Exception("Unexpected HTML response from API. This could indicate a network issue, proxy configuration problem, or API endpoint change.")
                    
                    # Handle regular JSON responses
                    elif 'application/json' in content_type:
                        try:
                            error_data = response.json()
                            error_type = error_data.get("error", {}).get("type", "unknown")
                            error_message = error_data.get("error", {}).get("message", "Unknown error")
                            
                            # Authentication errors
                            if error_type == "authentication_error" or response.status_code == 401:
                                if "invalid" in error_message.lower() and "api" in error_message.lower():
                                    raise Exception(f"Invalid API key: Your Anthropic API key appears to be invalid. Please check that you've entered it correctly.")
                                elif "expired" in error_message.lower():
                                    raise Exception(f"Expired API key: Your Anthropic API key has expired. Please generate a new key in your Anthropic console.")
                                else:
                                    raise Exception(f"Authentication error: {error_message}. Check your API key.")
                            
                            # Rate limit errors
                            elif error_type == "rate_limit_error" or response.status_code == 429:
                                raise Exception(f"Rate limit exceeded: {error_message}. Please try again later.")
                            
                            # Invalid request errors
                            elif error_type == "invalid_request_error" or response.status_code == 400:
                                if "model" in error_message.lower():
                                    raise Exception(f"Model error: {error_message}. Try using a different Claude model.")
                                else:
                                    raise Exception(f"Invalid request: {error_message}")
                            
                            # Server errors
                            elif response.status_code >= 500:
                                raise Exception(f"Anthropic server error: {error_message}. Please try again later.")
                            
                            # Other errors
                            else:
                                raise Exception(f"API Error ({error_type}): {error_message}")
                        except json.JSONDecodeError:
                            # Handle case where content-type is application/json but content isn't valid JSON
                            logger.error(f"Invalid JSON in error response (content-type: {content_type})")
                            raise Exception(f"Error parsing API response: Invalid JSON received. Response starts with: {response.text[:100]}...")
                    else:
                        # Other non-JSON response types
                        logger.error(f"Unexpected content type: {content_type}")
                        raise Exception(f"API Error (HTTP {response.status_code}): Unexpected content type '{content_type}'. Response: {response.text[:200]}...")
                        
                except json.JSONDecodeError as json_err:
                    # Specific handling for JSON parsing errors
                    logger.error(f"JSON parsing error: {str(json_err)}")
                    
                    # Check if response looks like HTML
                    if response.text.strip().startswith(('<!DOCTYPE', '<html')):
                        raise Exception("Received HTML instead of JSON. This usually indicates a network issue or proxy interference. Check your internet connection and try again.")
                    else:
                        raise Exception(f"JSON parsing error: {str(json_err)}. Response begins with: {response.text[:100]}...")
                
                except Exception as parse_error:
                    # Generic error handling for any other exceptions
                    logger.error(f"Error parsing API response: {str(parse_error)}")
                    raise Exception(f"API Error (HTTP {response.status_code}): {str(parse_error)}")
    
    except Exception as e:
        logger.error(f"Error calling Claude API: {str(e)}")
        return f"Error: {str(e)}"

# For testing outside of Blender
if __name__ == "__main__":
    # Test the API with demo mode
    demo_response = ask_claude(
        "How do I create a better material for my model?",
        use_demo_mode=True
    )
    print("Demo response:")
    print(demo_response)
    
    # Test with API key if provided
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if api_key:
        print("\nTesting with actual API key:")
        response = ask_claude(
            "What's the best way to improve my Blender skills?",
            api_key=api_key,
            model="claude-3-haiku-20240307"  # Using a smaller model for testing
        )
        print(response)
    else:
        print("\nNo API key found in environment. Skipping API test.")