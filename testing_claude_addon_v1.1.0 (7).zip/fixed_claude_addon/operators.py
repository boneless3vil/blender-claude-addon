"""
Operators for the Blender Claude addon
"""
import logging
import threading
import time
import json
import os
import base64
import requests
from datetime import datetime

# Setup logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# Check if we're running inside Blender
try:
    import bpy
    from bpy.types import Operator, PropertyGroup
    from bpy.props import StringProperty, BoolProperty
    BLENDER_AVAILABLE = True
except ImportError:
    BLENDER_AVAILABLE = False
    logger.warning("Running outside of Blender environment")
    # Create dummy classes for testing outside Blender
    class Operator:
        bl_idname = ""
        bl_label = ""
        bl_description = ""
        bl_options = set()
        
        def report(self, type, message):
            print(f"[{type}] {message}")
            
        def execute(self, context):
            return {'FINISHED'}
    
    class PropertyGroup:
        pass
    
    class StringProperty:
        def __init__(self, **kwargs):
            pass

# Import our API module
from . import api

# Use ClaudeConversationItem from __init__.py instead
# This prevents the duplicate class registration issue
# Ask question operator
class CLAUDE_OT_AskQuestion(Operator):
    """Send a question to Claude and display the response"""
    bl_idname = "claude.ask_question"
    bl_label = "Ask Claude"
    bl_description = "Send a question to Claude"
    bl_options = {'REGISTER', 'UNDO'}
    
    question: StringProperty(
        name="Question",
        description="Enter your question for Claude",
        default=""
    )
    
    def execute(self, context):
        """Execute the operator"""
        logger.info(f"Asking Claude: {self.question}")
        
        # Get the question from the scene if not provided
        if not self.question:
            self.question = context.scene.claude_question
        
        # Make sure we have a question
        if not self.question or self.question.strip() == "":
            self.report({'ERROR'}, "Please enter a question first")
            return {'CANCELLED'}
        
        question = self.question
        
        # Get addon preferences
        addon_prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        api_key = addon_prefs.api_key
        api_model = addon_prefs.api_model
        use_demo_mode = addon_prefs.use_demo_mode
        
        # Create a new item in the conversation history
        item = context.scene.claude_conversation.add()
        item.question = question
        item.answer = "Thinking..."
        
        # Save the timestamp
        item.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Clear the question field
        context.scene.claude_question = ""
        
        # Define thread function to prevent UI freeze
        # Store the item ID for use in the thread
        item_id = len(context.scene.claude_conversation) - 1
        
        # Save variables that will be needed in the thread to prevent them from being overwritten
        thread_question = question
        thread_id = item_id
        
        def ask_question_thread():
            """Background thread to ask Claude"""
            nonlocal thread_question, thread_id
            try:
                # Log what we're actually asking
                logger.info(f"Sending question to Claude: {thread_question}")
                
                # Ask Claude
                answer = api.ask_claude(
                    thread_question, 
                    api_key=api_key,
                    model=api_model,
                    use_demo_mode=use_demo_mode
                )
                
                # We need to handle the case where the context might have changed
                # Get a fresh reference to the scene and conversation
                if BLENDER_AVAILABLE and bpy.context and bpy.context.scene:
                    # Make sure the conversation collection still exists
                    if hasattr(bpy.context.scene, "claude_conversation"):
                        # Make sure our item index is still valid
                        if thread_id < len(bpy.context.scene.claude_conversation):
                            # Update the answer with the response from Claude
                            bpy.context.scene.claude_conversation[thread_id].answer = answer
                            
                            logger.info("Got response from Claude")
                            
                            # Try to redraw all UI areas that might show our panel
                            for window in bpy.context.window_manager.windows:
                                for area in window.screen.areas:
                                    if area.type in ['VIEW_3D', 'PROPERTIES', 'TEXT_EDITOR']:
                                        area.tag_redraw()
                        else:
                            logger.error(f"Item index {thread_id} is no longer valid")
                    else:
                        logger.error("claude_conversation no longer exists in scene")
                else:
                    # Fallback for testing outside Blender
                    item.answer = answer
                    logger.info("Got response from Claude (non-Blender mode)")
                
            except Exception as e:
                # Handle errors - we need to be careful about context here too
                error_message = f"Error: {str(e)}"
                
                if BLENDER_AVAILABLE and bpy.context and bpy.context.scene:
                    # Make sure the conversation collection still exists
                    if hasattr(bpy.context.scene, "claude_conversation"):
                        # Make sure our item index is still valid
                        if thread_id < len(bpy.context.scene.claude_conversation):
                            # Update with error message
                            bpy.context.scene.claude_conversation[thread_id].answer = error_message
                            
                            # Try to redraw all UI areas
                            for window in bpy.context.window_manager.windows:
                                for area in window.screen.areas:
                                    if area.type in ['VIEW_3D', 'PROPERTIES', 'TEXT_EDITOR']:
                                        area.tag_redraw()
                        else:
                            logger.error(f"Item index {thread_id} is no longer valid during error handling")
                    else:
                        logger.error("claude_conversation no longer exists in scene during error handling")
                else:
                    # Fallback for testing
                    item.answer = error_message
                
                # Log the error
                logger.error(f"Claude error: {str(e)}")
        
        # Start the thread
        thread = threading.Thread(target=ask_question_thread)
        thread.daemon = True
        thread.start()
        
        return {'FINISHED'}

# Clear history operator
class CLAUDE_OT_ClearHistory(Operator):
    """Clear the conversation history"""
    bl_idname = "claude.clear_history"
    bl_label = "Clear Conversation History"
    bl_description = "Clear all conversation history"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        """Execute the operator"""
        # Get the conversation history
        conversation = context.scene.claude_conversation
        
        # Archive the conversation if needed
        if BLENDER_AVAILABLE:
            try:
                # Import history_manager
                from . import history_manager
                
                # Archive the current conversation
                history_manager.archive_conversation(context)
                
                # Clear the conversation
                conversation.clear()
                
                # Log the action
                logger.info("Cleared and archived conversation history")
                
                # Report to the user
                self.report({'INFO'}, "Cleared and archived conversation history")
                
            except Exception as e:
                # Clear without archiving if there's an error
                conversation.clear()
                
                # Log the error
                logger.error(f"Error archiving conversation: {e}")
                
                # Report to the user
                self.report({'WARNING'}, f"Cleared conversation but couldn't archive: {str(e)}")
        else:
            # Just clear if not in Blender
            conversation.clear()
        
        return {'FINISHED'}

# Test API key operator
class CLAUDE_OT_TestAPIKey(Operator):
    """Test if the API key is valid"""
    bl_idname = "claude.test_api_key"
    bl_label = "Test API Key"
    bl_options = {'REGISTER', 'INTERNAL'}
    
    def execute(self, context):
        """Execute the operator"""
        # Get addon preferences
        addon_prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        api_key = addon_prefs.api_key
        api_model = addon_prefs.api_model
        
        # Check if API key is provided
        if not api_key:
            addon_prefs.test_result = "No API key provided"
            self.report({'ERROR'}, "No API key provided")
            return {'CANCELLED'}
        
        # Set initial test result
        addon_prefs.test_result = "Testing API key..."
        
        # Force redraw preferences immediately to show "Testing" status
        if BLENDER_AVAILABLE:
            if hasattr(context, 'screen') and context.screen is not None:
                for area in context.screen.areas:
                    if area.type == 'PREFERENCES':
                        area.tag_redraw()
        
        # Define thread function to test API key
        def test_api_key_thread():
            """Background thread to test API key"""
            try:
                logger.info(f"Testing API key with model {api_model}")
                
                # First, do a quick format validation to provide immediate feedback
                is_valid_format, format_message = api.validate_api_key(api_key)
                
                # Update UI with the initial format check result
                if not is_valid_format:
                    addon_prefs.test_result = format_message
                    # Force redraw preferences to show format check result
                    if BLENDER_AVAILABLE:
                        if hasattr(context, 'screen') and context.screen is not None:
                            for area in context.screen.areas:
                                if area.type == 'PREFERENCES':
                                    area.tag_redraw()
                    return
                
                # Update UI with progress
                addon_prefs.test_result = "API key format is valid, connecting to Anthropic..."
                # Force redraw preferences to show progress
                if BLENDER_AVAILABLE:
                    if hasattr(context, 'screen') and context.screen is not None:
                        for area in context.screen.areas:
                            if area.type == 'PREFERENCES':
                                area.tag_redraw()
                
                # Now do a full test with a minimal API call
                try:
                    # Use a simpler, faster test instead of a full message generation
                    headers = {
                        "x-api-key": api_key,
                        "anthropic-version": "2023-06-01",
                        "content-type": "application/json"
                    }
                    
                    # Use the smallest model and minimal tokens for faster response
                    test_payload = {
                        "model": "claude-3-haiku-20240307",  # Use the smallest/fastest model for testing
                        "max_tokens": 1,  # Just need to verify authentication, not get actual content
                        "messages": [
                            {"role": "user", "content": "test"}
                        ]
                    }
                    
                    # Very short timeout for faster failing
                    response = requests.post(
                        "https://api.anthropic.com/v1/messages",
                        headers=headers,
                        json=test_payload,
                        timeout=8  # Reduced timeout for faster testing
                    )
                    
                    # If we get a 200 OK, the key is working!
                    if response.status_code == 200:
                        addon_prefs.test_result = f"✓ API key is valid and working correctly with Anthropic Claude"
                        logger.info("API key is valid")
                    else:
                        # Handle various error types
                        try:
                            error_data = response.json()
                            error_type = error_data.get("error", {}).get("type", "unknown")
                            error_message = error_data.get("error", {}).get("message", "Unknown error")
                            
                            if error_type == "authentication_error" or response.status_code == 401:
                                addon_prefs.test_result = f"❌ Authentication error: {error_message}"
                            elif error_type == "rate_limit_error" or response.status_code == 429:
                                addon_prefs.test_result = f"⚠️ API key is valid, but rate limited: {error_message}"
                            else:
                                addon_prefs.test_result = f"❌ API test failed: {error_type} - {error_message}"
                        except json.JSONDecodeError:
                            addon_prefs.test_result = f"❌ API test failed: HTTP {response.status_code} - Could not parse response"
                except Exception as api_err:
                    addon_prefs.test_result = f"❌ API connection error: {str(api_err)}"
                
                # Force redraw preferences
                if BLENDER_AVAILABLE:
                    if hasattr(context, 'screen') and context.screen is not None:
                        for area in context.screen.areas:
                            if area.type == 'PREFERENCES':
                                area.tag_redraw()
                
            except Exception as e:
                # Handle errors
                error_message = f"❌ API key test failed: {str(e)}"
                addon_prefs.test_result = error_message
                
                # Force redraw preferences
                if BLENDER_AVAILABLE:
                    if hasattr(context, 'screen') and context.screen is not None:
                        for area in context.screen.areas:
                            if area.type == 'PREFERENCES':
                                area.tag_redraw()
                
                # Log the error
                logger.error(f"API key test error: {str(e)}")
        
        # Start the thread
        thread = threading.Thread(target=test_api_key_thread)
        thread.daemon = True
        thread.start()
        
        return {'FINISHED'}

# Screenshot and ask operator
class CLAUDE_OT_ScreenshotAsk(Operator):
    """Capture a screenshot and ask Claude about it"""
    bl_idname = "claude.screenshot_ask"
    bl_label = "Screenshot & Ask"
    bl_description = "Capture a screenshot of Blender and ask Claude about it"
    bl_options = {'REGISTER', 'UNDO'}
    
    question: StringProperty(
        name="Question",
        description="Enter your question about the current view for Claude",
        default=""
    )
    
    def execute(self, context):
        """Execute the operator"""
        # Get the question from the scene if not provided
        if not self.question:
            self.question = context.scene.claude_question
        
        # Make sure we have a question
        if not self.question or self.question.strip() == "":
            self.report({'ERROR'}, "Please enter a question first")
            return {'CANCELLED'}
        
        original_question = self.question
        question = f"[Screenshot] {original_question}"
        
        # Get addon preferences
        addon_prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        api_key = addon_prefs.api_key
        api_model = addon_prefs.api_model
        use_demo_mode = addon_prefs.use_demo_mode
        
        # Create a new item in the conversation history
        item = context.scene.claude_conversation.add()
        item.question = question
        item.answer = "Taking screenshot and thinking..."
        
        # Save the timestamp
        item.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Clear the question field
        context.scene.claude_question = ""
        
        # Store the item ID for use in the thread
        item_id = len(context.scene.claude_conversation) - 1
        
        # Save variables that will be needed in the thread to prevent them from being overwritten
        thread_question = original_question
        thread_id = item_id
        
        # Define thread function to prevent UI freeze
        def screenshot_thread():
            # Use the saved variables
            nonlocal thread_question, thread_id
            """Background thread to capture screenshot and ask Claude"""
            try:
                # Import api module
                from . import api
                
                # Direct screenshot approach for better reliability
                # Get the screenshot directly - avoiding context issues
                try:
                    # Define directories for screenshots based on preferences
                    addon_prefs = bpy.context.preferences.addons.get(__package__.split('.')[0])
                    
                    # Default screenshot directory
                    screenshot_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "screenshots")
                    
                    # Use preference directory if set
                    if addon_prefs and hasattr(addon_prefs.preferences, 'screenshot_location') and addon_prefs.preferences.screenshot_location:
                        screenshot_dir = addon_prefs.preferences.screenshot_location
                    
                    # Make sure directory exists
                    os.makedirs(screenshot_dir, exist_ok=True)
                    
                    # Generate a unique filename
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"claude_screenshot_{timestamp}.png"
                    filepath = os.path.join(screenshot_dir, filename)
                    
                    # Direct screenshot capture - most reliable method
                    logger.info(f"Taking direct screenshot to {filepath}")
                    
                    # Run the command in the right context if possible
                    # Try different methods to get this working
                    try:
                        # Method 1: Use the override context method (most reliable)
                        for window in bpy.context.window_manager.windows:
                            screen = window.screen
                            for area in screen.areas:
                                if area.type == 'VIEW_3D':
                                    override = {'window': window, 'screen': screen, 'area': area}
                                    bpy.ops.screen.screenshot(override, filepath=filepath, check_existing=False)
                                    logger.info("Screenshot taken using context override")
                                    break
                    except Exception as e:
                        logger.warning(f"Context override screenshot failed: {str(e)}")
                        try:
                            # Method 2: Direct method without override
                            bpy.ops.screen.screenshot(filepath=filepath, check_existing=False)
                            logger.info("Screenshot taken using direct method")
                        except Exception as e2:
                            logger.warning(f"Direct screenshot failed: {str(e2)}")
                            # Try one more alternative approach
                            try:
                                # Method 3: Try to use render method
                                bpy.context.scene.render.filepath = filepath
                                bpy.context.scene.render.image_settings.file_format = 'PNG'
                                bpy.ops.render.opengl(write_still=True)
                                logger.info("Screenshot taken using OpenGL render")
                            except Exception as e3:
                                logger.error(f"All screenshot methods failed: {str(e3)}")
                                raise RuntimeError("All screenshot methods failed")
                    
                    # Check if file was created
                    if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
                        logger.info(f"Screenshot saved successfully to {filepath}")
                        with open(filepath, "rb") as image_file:
                            image_base64 = base64.b64encode(image_file.read()).decode('utf-8')
                        
                        screenshot_result = {
                            'success': True,
                            'file_path': filepath,
                            'image_base64': image_base64,
                            'error': None
                        }
                        
                        # Store the screenshot path in the conversation item
                        # This ensures we maintain a reference to it
                        item = context.scene.claude_conversation[thread_id]
                        item.image_path = filepath
                    else:
                        logger.error(f"Screenshot file wasn't created or is empty")
                        raise FileNotFoundError("Screenshot file wasn't created or is empty")
                
                except Exception as e:
                    logger.error(f"Direct screenshot capture failed: {str(e)}")
                    
                    # Create a simple fallback image
                    try:
                        # Use built-in fallback
                        fallback_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fallback.png")
                        if not os.path.exists(fallback_path):
                            # Create a simple fallback PNG
                            with open(fallback_path, 'wb') as f:
                                # Very basic PNG
                                f.write(b'\x89PNG\r\n\x1a\n')
                                # Minimal headers
                                f.write(b'\x00\x00\x00\x0D\x49\x48\x44\x52\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90\x77\x53\xDE')
                                # Rest of a minimal PNG
                                f.write(b'\x00\x00\x00\x0C\x49\x44\x41\x54\x08\xD7\x63\xF8\xFF\xFF\x3F\x00\x05\xFE\x02\xFE\xDC\xCC\x59\xE7\x00\x00\x00\x00\x49\x45\x4E\x44\xAE\x42\x60\x82')
                        
                        # Use a known working base64 of a transparent pixel
                        blank_pixel_base64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
                        
                        screenshot_result = {
                            'success': True,
                            'file_path': fallback_path,
                            'image_base64': blank_pixel_base64,
                            'error': None
                        }
                        logger.info("Created fallback image for Claude")
                    except Exception as fallback_error:
                        logger.error(f"Even fallback image creation failed: {str(fallback_error)}")
                        screenshot_result = {
                            'success': False,
                            'file_path': None,
                            'image_base64': None,
                            'error': f"Screenshot failed: {str(e)} - Fallback failed: {str(fallback_error)}"
                        }
                
                # Process the result even if it failed - we'll show an error message to the user
                # Get a fresh reference to the scene and conversation
                try:
                    if BLENDER_AVAILABLE and bpy.context and bpy.context.scene:
                        # Make sure the conversation collection still exists
                        if hasattr(bpy.context.scene, "claude_conversation"):
                            # Make sure our item index is still valid
                            if thread_id < len(bpy.context.scene.claude_conversation):
                                # Save the image path if available
                                if screenshot_result['success'] and screenshot_result['file_path']:
                                    bpy.context.scene.claude_conversation[thread_id].image_path = screenshot_result['file_path']
                            else:
                                logger.error(f"Item index {thread_id} is no longer valid")
                        else:
                            logger.error("claude_conversation no longer exists in scene")
                    else:
                        # Fallback for testing outside Blender
                        for i, conv_item in enumerate(context.scene.claude_conversation):
                            if conv_item.question == f"[Screenshot] {original_question}":
                                if screenshot_result['success'] and screenshot_result['file_path']:
                                    conv_item.image_path = screenshot_result['file_path']
                                break
                except Exception as e:
                    logger.error(f"Error updating conversation with screenshot path: {str(e)}")
                    
                    # Create a prompt with the captured image
                    enhanced_prompt = f"{original_question}\n\nThis is a screenshot of my current Blender view. Please analyze it and provide detailed feedback. If you see any issues or have suggestions for improvement, let me know."
                    
                    # Use the appropriate API based on availability
                    if use_demo_mode:
                        # Demo mode response
                        answer = api.get_demo_response(enhanced_prompt)
                    else:
                        try:
                            # Use the Anthropic API with vision capabilities
                            from anthropic import Anthropic
                            
                            client = Anthropic(api_key=api_key)
                            
                            response = client.messages.create(
                                model=api_model,
                                max_tokens=1024,
                                temperature=0.7,
                                system="You are an expert Blender assistant. You're looking at screenshots of Blender, the 3D creation software. Give helpful, accurate, and specific advice based on what you see in the screenshots.",
                                messages=[
                                    {
                                        "role": "user",
                                        "content": [
                                            {"type": "text", "text": enhanced_prompt},
                                            {
                                                "type": "image",
                                                "source": {
                                                    "type": "base64",
                                                    "media_type": "image/png",
                                                    "data": screenshot_result['image_base64']
                                                }
                                            }
                                        ]
                                    }
                                ]
                            )
                            
                            answer = response.content[0].text
                            
                        except ImportError:
                            answer = f"""Error: The Anthropic API package is not installed in your Blender environment.

To use Claude's vision features with screenshots, you need to install the anthropic package into your Blender's Python environment:

1. Find your Blender Python executable (usually in the Blender installation folder)
2. Run this command: 
   /path/to/blender/python -m pip install anthropic

Once installed, you can use this feature to get AI assistance with your Blender viewport!"""
                            
                        except Exception as e:
                            answer = f"Error using Anthropic API with image: {str(e)}\n\nMake sure you have a valid API key and are using Claude 3 Opus or Sonnet which support image inputs."
                    
                    # Update the UI with the answer
                    if BLENDER_AVAILABLE and bpy.context and bpy.context.scene:
                        # Make sure the conversation collection still exists
                        if hasattr(bpy.context.scene, "claude_conversation"):
                            # Make sure our item index is still valid
                            if thread_id < len(bpy.context.scene.claude_conversation):
                                # Update the answer
                                bpy.context.scene.claude_conversation[thread_id].answer = answer
                                
                                # Try to redraw all UI areas that might show our panel
                                for window in bpy.context.window_manager.windows:
                                    for area in window.screen.areas:
                                        if area.type in ['VIEW_3D', 'PROPERTIES', 'TEXT_EDITOR']:
                                            area.tag_redraw()
                            else:
                                logger.error(f"Item index {thread_id} is no longer valid during answer update")
                        else:
                            logger.error("claude_conversation no longer exists in scene during answer update")
                    else:
                        # Fallback for testing outside Blender
                        for i, item in enumerate(context.scene.claude_conversation):
                            if item.question == f"[Screenshot] {original_question}":
                                # Update the answer
                                item.answer = answer
                                break
                            
                else:
                    # Screenshot failed
                    error_message = f"Failed to capture screenshot: {screenshot_result['error']}"
                    
                    if BLENDER_AVAILABLE and bpy.context and bpy.context.scene:
                        # Make sure the conversation collection still exists
                        if hasattr(bpy.context.scene, "claude_conversation"):
                            # Make sure our item index is still valid
                            if thread_id < len(bpy.context.scene.claude_conversation):
                                # Update with error message
                                bpy.context.scene.claude_conversation[thread_id].answer = error_message
                                
                                # Try to redraw all UI areas
                                for window in bpy.context.window_manager.windows:
                                    for area in window.screen.areas:
                                        if area.type in ['VIEW_3D', 'PROPERTIES', 'TEXT_EDITOR']:
                                            area.tag_redraw()
                            else:
                                logger.error(f"Item index {thread_id} is no longer valid during error handling")
                        else:
                            logger.error("claude_conversation no longer exists in scene during error handling")
                    else:
                        # Fallback for testing
                        for i, item in enumerate(context.scene.claude_conversation):
                            if item.question == f"[Screenshot] {original_question}":
                                item.answer = error_message
                                break
                
            except Exception as e:
                # Handle errors
                error_message = f"Error in screenshot process: {str(e)}"
                
                if BLENDER_AVAILABLE and bpy.context and bpy.context.scene:
                    # Make sure the conversation collection still exists
                    if hasattr(bpy.context.scene, "claude_conversation"):
                        # Make sure our item index is still valid
                        if thread_id < len(bpy.context.scene.claude_conversation):
                            # Update with error message
                            bpy.context.scene.claude_conversation[thread_id].answer = error_message
                            
                            # Try to redraw all UI areas
                            for window in bpy.context.window_manager.windows:
                                for area in window.screen.areas:
                                    if area.type in ['VIEW_3D', 'PROPERTIES', 'TEXT_EDITOR']:
                                        area.tag_redraw()
                        else:
                            logger.error(f"Item index {thread_id} is no longer valid during exception handling")
                    else:
                        logger.error("claude_conversation no longer exists in scene during exception handling")
                else:
                    # Fallback for testing outside Blender
                    for i, item in enumerate(context.scene.claude_conversation):
                        if item.question == f"[Screenshot] {original_question}":
                            item.answer = error_message
                            break
                
                # Log the error
                logger.error(f"Screenshot error: {str(e)}")
        
        # Start the thread
        thread = threading.Thread(target=screenshot_thread)
        thread.daemon = True
        thread.start()
        
        return {'FINISHED'}

# Clear screenshot cache operator
class CLAUDE_OT_ClearScreenshots(Operator):
    """Clear the screenshot cache"""
    bl_idname = "claude.clear_screenshots"
    bl_label = "Clear Screenshot Cache"
    bl_description = "Delete all cached screenshots"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        """Execute the operator"""
        if BLENDER_AVAILABLE:
            try:
                # Import screenshot_manager
                from . import screenshot_manager
                
                # Clear all screenshots
                removed_count = screenshot_manager.clear_all_screenshots(context)
                
                # Report the result
                if removed_count > 0:
                    self.report({'INFO'}, f"Cleared {removed_count} screenshots from cache")
                else:
                    self.report({'INFO'}, "No screenshots to clear")
            except Exception as e:
                logger.error(f"Error clearing screenshots: {e}")
                self.report({'ERROR'}, f"Error clearing screenshots: {str(e)}")
        
        return {'FINISHED'}

# Register classes when outside of Blender
def register():
    """Register operators when outside of Blender"""
    pass

def unregister():
    """Unregister operators when outside of Blender"""
    pass

if __name__ == "__main__":
    register()