"""
Blender Claude Addon - AI assistant powered by Anthropic's Claude
Compatible with Blender 4.4 and above. Includes icon compatibility fixes,
improved screenshot functionality, and enhanced Anthropic module handling.

New in v1.1.0:1002
- Improved screenshot capture with multiple backup methods for Blender 4.4 compatibility
- Enhanced fallback image generation that always produces valid images
- Fixed API key validation to accept all valid Anthropic key formats
- Multiple context handling improvements for more reliable operation
- Better error messages and logging for troubleshooting

New in v1.0.1:1001
- Cross-platform path handling using os.path instead of hardcoded paths
- Fixed Enter key handling to prevent double-pressing issues
- Enhanced text wrapping for better readability when panel is resized
- Simplified code block highlighting for better reliability

New in v1.1.0:1001
- Bundled Anthropic module inside addon for guaranteed compatibility
- Better feedback in preferences panel showing API module status
- More informative error messages when in fallback REST API mode
- Enhanced screenshot handling with Claude for better context
"""

bl_info = {
    "name": "Claude AI Assistant",
    "author": "YourName",
    "version": (1, 1, 0, 1002),  # major.minor.patch.build
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Claude",
    "description": "Integrate Anthropic's Claude AI assistant directly in Blender with enhanced screenshot capability",
    "warning": "",
    "doc_url": "",
    "category": "3D View",
}

# Standard library imports
import logging
import os
import sys
import importlib.util
import bpy
from bpy.props import StringProperty, EnumProperty, BoolProperty, CollectionProperty, IntProperty
from bpy.types import PropertyGroup, AddonPreferences

# Setup logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# Check if we're running inside Blender
try:
    import bpy
    BLENDER_AVAILABLE = True
except ImportError:
    BLENDER_AVAILABLE = False

# Add vendor packages to the Python path
addon_dir = os.path.dirname(os.path.abspath(__file__))
vendor_dir = os.path.join(addon_dir, "vendor", "packages")
if os.path.exists(vendor_dir) and vendor_dir not in sys.path:
    logger.info(f"Adding vendor directory to path: {vendor_dir}")
    sys.path.insert(0, vendor_dir)
    
# Import our own modules (which will check for anthropic)
from . import api

# Make the anthropic module status available here
ANTHROPIC_AVAILABLE = api.ANTHROPIC_AVAILABLE

if not BLENDER_AVAILABLE:
    logger.warning("Running outside of Blender environment")

# Store addon preferences globally
addon_prefs = None

# Define PropertyGroup classes for the addon
class ClaudeConversationItem(PropertyGroup):
    """Class to store a single conversation item"""
    question: StringProperty()
    answer: StringProperty()
    image_path: StringProperty(default="")
    timestamp: StringProperty(default="")

# Define addon preferences
class ClaudeAddonPreferences(AddonPreferences):
    """Addon preferences, visible in Blender's addon panel"""
    bl_idname = __name__

    api_key: StringProperty(
        name="Anthropic API Key",
        description="Enter your Anthropic API key (stored securely in Blender preferences)",
        default="",
        subtype='PASSWORD'
    )
    
    api_model: EnumProperty(
        name="Claude Model",
        description="Select which Claude model to use",
        items=[
            ("claude-3-opus-20240229", "Claude 3 Opus", "Most powerful model, best for complex tasks and detailed analysis"),
            ("claude-3-sonnet-20240229", "Claude 3 Sonnet", "Excellent balance of intelligence and speed"),
            ("claude-3-haiku-20240307", "Claude 3 Haiku", "Fast and efficient for simpler tasks")
        ],
        default="claude-3-opus-20240229"
    )
    
    use_demo_mode: BoolProperty(
        name="Demo Mode",
        description="Enable demo mode to use pre-written responses without an API key (no tokens spent!)",
        default=True
    )
    
    test_result: StringProperty(
        name="API Key Test Result",
        description="Result of the API key test",
        default=""
    )
    
    archive_location: StringProperty(
        name="History Archive Location",
        description="Directory to save archived conversations",
        default=os.path.join(os.path.expanduser("~"), "Documents", "blender", "claude_addon", "history"),
        subtype='DIR_PATH'
    )
    
    screenshot_location: StringProperty(
        name="Screenshot Storage Location",
        description="Directory to save screenshots",
        default=os.path.join(os.path.expanduser("~"), "Documents", "blender", "claude_addon", "screenshots"),
        subtype='DIR_PATH'
    )
    
    max_conversation_items: IntProperty(
        name="Max Conversation Items",
        description="Maximum number of conversation items to keep in memory (older items will be archived)",
        default=20,
        min=5,
        max=100
    )
    
    def draw(self, context):
        """Draw the preferences panel"""
        layout = self.layout
        
        # API key section
        box = layout.box()
        box.label(text="API Configuration:")
        box.prop(self, "api_key")
        
        # Test API key button
        row = box.row()
        row.operator("claude.test_api_key", text="Test API Key")
        
        # API test result
        if self.test_result:
            result_box = box.box()
            result_box.label(text=self.test_result)
        
        # Model selection
        box.prop(self, "api_model")
        box.prop(self, "use_demo_mode")
        
        # Conversation settings
        box = layout.box()
        box.label(text="Conversation Settings:")
        box.prop(self, "max_conversation_items")
        box.prop(self, "archive_location")
        
        # Screenshot settings
        box = layout.box()
        box.label(text="Screenshot Settings:")
        box.prop(self, "screenshot_location")
        
        # Clear screenshots button
        row = box.row()
        row.operator("claude.clear_screenshots", text="Clear Screenshot Cache")
        
        # API module status
        box = layout.box()
        box.label(text="API Module Status:")
        
        if ANTHROPIC_AVAILABLE:
            status_row = box.row()
            status_row.label(text="✓ Anthropic API module found and working correctly", icon='CHECKMARK')
            info_box = box.box()
            info_box.label(text="The addon is using the bundled Anthropic module for optimal performance.")
        else:
            status_row = box.row() 
            status_row.label(text="⚠ Anthropic API module not found - using REST API fallback mode", icon='ERROR')
            help_box = box.box()
            help_box.label(text="Attempting to use bundled Anthropic module failed. This should not happen.")
            help_box.label(text="Please try reinstalling the addon or contact support.")
        
        # Info and documentation
        box = layout.box()
        box.label(text="About Claude AI Assistant:")
        box.label(text="This addon integrates Anthropic's Claude AI into Blender")
        box.label(text="Set your API key above to get started, or use Demo Mode")
        box.label(text="For support, visit: github.com/yourusername/blender-claude-addon")

class CLAUDE_OT_AskWithEnter(bpy.types.Operator):
    """Press Enter to submit your question to Claude"""
    bl_idname = "claude.ask_with_enter"
    bl_label = "Ask Claude (Enter)"
    bl_options = {'INTERNAL'}
    
    # Keymap entry handle
    _keymaps = []
    
    def execute(self, context):
        """Execute when Enter is pressed in the question field"""
        # Get the question from the scene
        question = context.scene.claude_question
        
        # Check if the UI is active (user is interacting with our panel)
        # This helps prevent the double-trigger issue
        active_area = context.area
        if not active_area or active_area.type != 'VIEW_3D':
            # Only respond to Enter key in 3D view where our panel is
            return {'PASS_THROUGH'}
            
        # If focus is on a text field in our panel AND there's a question
        if question and question.strip():
            # Send the question
            bpy.ops.claude.ask_question(question=question)
            # Clear the input field to avoid double-submit
            context.scene.claude_question = ""
            return {'FINISHED'}
        
        # Let other handlers process the event if we're not handling it
        return {'PASS_THROUGH'}
    
    @classmethod
    def register(cls):
        """Register keymap for Enter key support"""
        if bpy.context is None:
            return
            
        # Get the window manager to add our keymap
        wm = bpy.context.window_manager
        
        # Get active keyconfig (usually "Blender")
        kc = wm.keyconfigs.addon
        
        # If there's no addon keyconfig, return
        if not kc:
            return
            
        # Add a keymap entry for the 3D View UI region
        # This makes the keymap only active in the UI panel region where our add-on is
        km = kc.keymaps.new(name="3D View", space_type='VIEW_3D', region_type='UI')
        
        # Add a keymap item for the Enter key
        # This maps Enter to our operator
        kmi = km.keymap_items.new(cls.bl_idname, 'RET', 'PRESS')
        
        # Store to clean up on unregister
        cls._keymaps.append((km, kmi))
    
    @classmethod
    def unregister(cls):
        """Unregister keymap for Enter key support"""
        # Remove all keymap entries
        for km, kmi in cls._keymaps:
            # If the keymap entry still exists, remove it
            if km.keymap_items.find(kmi.id) != -1:
                km.keymap_items.remove(kmi)
        
        # Clear the list
        cls._keymaps.clear()

# Only import the rest if running inside Blender
if BLENDER_AVAILABLE:
    from bpy.utils import register_class, unregister_class
    
    # Import our modules
    from . import operators
    from . import panel
    from . import screenshot
    
    # Register scene properties
    def register_properties():
        # Check if properties are already registered (could happen during addon reload)
        # and only register if they're not already there
        if not hasattr(bpy.types.Scene, "claude_conversation"):
            bpy.types.Scene.claude_conversation = CollectionProperty(type=ClaudeConversationItem)
            
        if not hasattr(bpy.types.Scene, "claude_question"):
            bpy.types.Scene.claude_question = StringProperty(
                name="Ask Claude",
                description="Enter your question for Claude and press Enter to submit",
                default=""
            )
        
    # We use the CLAUDE_OT_AskWithEnter class defined earlier
    # This is a new approach for Enter key support in Blender 4.4+
    # Instead of using keypress_event handlers (which were removed in 4.4)
    # we now use an operator with a keymap
    
    # Unregister scene properties
    def unregister_properties():
        # Only delete properties if they exist
        if hasattr(bpy.types.Scene, "claude_conversation"):
            del bpy.types.Scene.claude_conversation
            
        if hasattr(bpy.types.Scene, "claude_question"):
            del bpy.types.Scene.claude_question

    # Classes to register
    classes = (
        ClaudeConversationItem,
        ClaudeAddonPreferences,
        CLAUDE_OT_AskWithEnter,  # Add our new Enter key handler
        operators.CLAUDE_OT_AskQuestion,
        operators.CLAUDE_OT_ClearHistory,
        operators.CLAUDE_OT_TestAPIKey,
        operators.CLAUDE_OT_ScreenshotAsk,
        operators.CLAUDE_OT_ClearScreenshots,
        panel.CLAUDE_PT_MainPanel
    )

# Register and unregister functions
def register():
    """Register the addon"""
    global addon_prefs
    
    if BLENDER_AVAILABLE:
        # First try to unregister any existing classes to prevent conflicts
        # This is important for addon reloading
        try:
            # Try to unregister existing classes that might be leftover
            # We wrap this in a try block since they might not be registered yet
            unregister()
        except Exception as e:
            # It's okay if unregistering fails - just means classes aren't registered yet
            logger.debug(f"Unregistering before register failed (normal on first load): {str(e)}")
            pass
            
        # Register all classes
        for cls in classes:
            try:
                register_class(cls)
            except Exception as e:
                # Log error but continue - might be just one class failing
                logger.error(f"Failed to register class {cls.__name__}: {str(e)}")
                raise  # Still raise the error to prevent partial registration
        
        # Register properties
        register_properties()
        
        # Register keymap for Enter key support
        # Will use the class method in CLAUDE_OT_AskWithEnter
        CLAUDE_OT_AskWithEnter.register()
        
        # Store preferences
        try:
            addon_prefs = bpy.context.preferences.addons[__name__].preferences
        except KeyError as e:
            logger.error(f"Could not access addon preferences: {str(e)}")
            # Don't raise this error as we can continue without preferences
        
        # Create default folders if they don't exist
        create_default_folders()
        
        logger.info("Blender Claude addon registered")
    
def create_default_folders():
    """Create default folders for history and screenshots if they don't exist"""
    global addon_prefs
    
    try:
        # Get preferences - first try using the global reference
        if not addon_prefs:
            try:
                # If the global variable isn't set yet, try to get it directly
                addon_prefs = bpy.context.preferences.addons[__name__].preferences
            except (AttributeError, KeyError) as e:
                logger.warning(f"Could not access addon preferences: {str(e)}")
                return
        
        # Create history folder if it exists and is set
        if hasattr(addon_prefs, 'archive_location') and addon_prefs.archive_location:
            if not os.path.exists(addon_prefs.archive_location):
                try:
                    os.makedirs(addon_prefs.archive_location, exist_ok=True)
                    logger.info(f"Created history folder: {addon_prefs.archive_location}")
                except Exception as folder_error:
                    logger.warning(f"Error creating history folder: {str(folder_error)}")
            
        # Create screenshots folder if it exists and is set
        if hasattr(addon_prefs, 'screenshot_location') and addon_prefs.screenshot_location:
            if not os.path.exists(addon_prefs.screenshot_location):
                try:
                    os.makedirs(addon_prefs.screenshot_location, exist_ok=True)
                    logger.info(f"Created screenshots folder: {addon_prefs.screenshot_location}")
                except Exception as folder_error:
                    logger.warning(f"Error creating screenshots folder: {str(folder_error)}")
                    
    except Exception as e:
        logger.error(f"Error handling default folders: {str(e)}")
        # Don't raise the exception, as this would prevent the addon from loading

def unregister():
    """Unregister the addon"""
    if BLENDER_AVAILABLE:
        # Unregister properties with error catching
        try:
            unregister_properties()
        except Exception as e:
            logger.warning(f"Error unregistering properties: {str(e)}")
        
        # Unregister keymap for Enter key support
        try:
            CLAUDE_OT_AskWithEnter.unregister()
        except Exception as e:
            logger.warning(f"Error unregistering keymap: {str(e)}")
        
        # Unregister all classes in reverse order with error catching
        for cls in reversed(classes):
            try:
                unregister_class(cls)
            except (ValueError, RuntimeError) as e:
                # Class might not be registered, which is fine
                logger.debug(f"Could not unregister {cls.__name__}: {str(e)}")
            except Exception as e:
                # Any other error is worth logging as a warning
                logger.warning(f"Error unregistering {cls.__name__}: {str(e)}")
        
        logger.info("Blender Claude addon unregistered")

# Register the addon if running as a script
if __name__ == "__main__" and BLENDER_AVAILABLE:
    register()