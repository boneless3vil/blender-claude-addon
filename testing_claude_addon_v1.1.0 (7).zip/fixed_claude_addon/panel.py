"""
Panel for the Blender Claude addon
"""
import logging
import textwrap

# Setup logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.WARNING)  # Only show warnings and errors, suppress info messages
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# Check if we're running inside Blender
try:
    import bpy
    from bpy.types import Panel
    BLENDER_AVAILABLE = True
except ImportError:
    BLENDER_AVAILABLE = False
    logger.warning("Running outside of Blender environment")
    # Create dummy classes for testing outside Blender
    class Panel:
        bl_space_type = ""
        bl_region_type = ""
        bl_category = ""
        bl_label = ""
        bl_idname = ""
        
        def draw(self, context):
            pass

class CLAUDE_PT_MainPanel(Panel):
    """Main panel for the Claude addon"""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Claude'
    bl_label = "Claude AI Assistant"
    bl_idname = "VIEW3D_PT_claude_ai"
    
    def draw(self, context):
        """Draw the panel"""
        layout = self.layout
        
        # Get the addon preferences
        addon_prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        # Add chat input field with Enter key support
        row = layout.row()
        
        # Simplified UI for input field with Enhanced Enter key support
        # We use a special event handler in __init__.py to capture Enter key
        # No need for a separate button since Enter key is supported
        layout.prop(context.scene, "claude_question", text="")
        
        # Add buttons for asking questions
        row = layout.row(align=True)
        row.operator("claude.ask_question", text="Ask Claude", icon='CHECKMARK')
        row.operator("claude.screenshot_ask", text="Screenshot & Ask", icon='IMAGE')
        
        # Add button for clearing history
        row = layout.row()
        row.operator("claude.clear_history", text="Clear History", icon='TRASH')
        
        # Add conversation history
        if hasattr(context.scene, "claude_conversation"):
            box = layout.box()
            box.label(text="Conversation History:", icon='TEXT')
            
            # Show conversation items in reverse order (newest first)
            for item in reversed(context.scene.claude_conversation):
                # Question from user
                question_box = box.box()
                
                # Get timestamp if available
                timestamp_text = ""
                if hasattr(item, "timestamp") and item.timestamp:
                    timestamp_text = f" ({item.timestamp})"
                
                # Use proper text alignment with USER icon
                question_with_prefix = f"You{timestamp_text}: {item.question}"
                self.draw_text_with_alignment(question_box, question_with_prefix, width=40, icon='USER')
                
                # Show image if available
                if hasattr(item, "image_path") and item.image_path:
                    try:
                        row = question_box.row()
                        row.label(text="Screenshot included", icon='IMAGE')
                    except Exception:
                        pass
                
                # Answer box for Claude's response
                answer_box = box.box()
                
                # Draw answer with proper alignment
                self.draw_text_with_alignment(answer_box, item.answer, width=40, icon='BLENDER')
                
                # Add separator
                box.separator()
        
        # Add demo mode notice if enabled
        if addon_prefs.use_demo_mode:
            box = layout.box()
            box.label(text="Demo Mode Active", icon='INFO')
            box.label(text="Using sample responses")
            box.label(text="Enter your API key in preferences")
            box.label(text="to use real Claude responses")
    
    def wrap_text(self, text, width):
        """Enhanced text wrapping to fit in the panel with proper justification"""
        # If text is empty, return empty list
        if not text:
            return []
            
        # For code blocks, preserve indentation
        if "```" in text:
            return self.wrap_code_blocks(text, width)
            
        # Check for natural line breaks and preserve them
        if "\n" in text:
            paragraphs = text.split("\n")
            result = []
            for paragraph in paragraphs:
                # If it's a blank line, preserve it
                if not paragraph.strip():
                    result.append("")
                    continue
                    
                # Otherwise wrap the paragraph
                result.extend(self._wrap_paragraph(paragraph, width))
            return result
        
        # Regular text wrapping for single paragraphs
        return self._wrap_paragraph(text, width)
    
    def _wrap_paragraph(self, text, width):
        """Internal method to wrap a single paragraph of text"""
        words = text.split()
        lines = []
        line = ""
        
        for word in words:
            # Special case for very long words
            if len(word) > width:
                # If we have a line in progress, finish it first
                if line:
                    lines.append(line)
                    line = ""
                
                # Split the long word itself
                for i in range(0, len(word), width):
                    if i + width <= len(word):
                        lines.append(word[i:i+width])
                    else:
                        line = word[i:]
                continue
                
            # Normal case - if adding this word doesn't exceed width, add it to the current line
            if len(line) + len(word) + 1 <= width:
                line = line + " " + word if line else word
            else:
                # Line is full, add it to lines and start a new line
                lines.append(line)
                line = word
        
        # Don't forget the last line
        if line:
            lines.append(line)
        
        return lines
        
    def wrap_code_blocks(self, text, width):
        """Simplified handling for text containing code blocks"""
        parts = text.split("```")
        result = []
        
        is_code_block = False
        for i, part in enumerate(parts):
            if not part:  # Empty part, skip
                is_code_block = not is_code_block
                continue
                
            if is_code_block:
                # This is a code block, preserve formatting
                code_lines = part.split("\n")
                if code_lines and not code_lines[0].strip():
                    # Remove the first line if it's blank (common in markdown)
                    code_lines = code_lines[1:]
                
                # Add code block markers with simple formatting
                result.append("▼ Code Block Start ▼")
                
                # Check for language specifier in first line
                if code_lines and not code_lines[0].startswith(" ") and not code_lines[0].startswith("\t"):
                    # This looks like a language specifier
                    language = code_lines[0].strip()
                    result.append(f"Language: {language}")
                    code_lines = code_lines[1:]  # Remove language line
                
                # Process each line in the code block
                for line in code_lines:
                    # Check for highlight markers
                    stripped = line.strip()
                    if stripped.startswith("// HIGHLIGHT:") or stripped.startswith("# HIGHLIGHT:"):
                        # Add an arrow marker for highlighted lines
                        result.append(f"➤ {line}")
                    elif stripped.startswith("// IMPORTANT:") or stripped.startswith("# IMPORTANT:"):
                        # Add a warning marker for important lines
                        result.append(f"⚠ {line}")
                    else:
                        # Regular code line
                        result.append(line)
                
                # End code block marker
                result.append("▲ Code Block End ▲")
            else:
                # Regular text outside code block
                result.extend(self._wrap_paragraph(part, width))
            
            is_code_block = not is_code_block
            
        return result
        
    def draw_text_with_alignment(self, layout, text, width, icon=None):
        """Draw text with proper alignment based on panel width"""
        # Get available width of the panel - safely handle context in case it's not available
        region_width = width
        try:
            # First try to get width from the current context
            if hasattr(bpy, "context") and hasattr(bpy.context, "area") and bpy.context.area:
                # Try to get the exact region the panel is in
                for region in bpy.context.area.regions:
                    if region.type == 'UI':
                        # Calculate usable width in characters
                        # UI panel width is measured in pixels, we need to convert to character count
                        # We need to account for margins and padding in the UI
                        panel_padding = 46  # Pixel padding for borders, margins, and scrollbar
                        char_width = 7.2    # Approximate pixel width per character (adjusted for Blender font)
                        
                        # Calculate usable characters per line, with a reasonable minimum
                        region_width = max(40, int((region.width - panel_padding) / char_width))
                        
                        # Keep width calculation but suppress logging
                        break
                        
            # Fallback to the layout's width if available
            if region_width == width and hasattr(layout, "width"):
                layout_width = getattr(layout, "width", 0)
                if layout_width > 0:
                    region_width = max(40, int((layout_width - 46) / 7.2))
                    
        except (AttributeError, TypeError) as e:
            # Fall back to default width if we can't access context area
            pass
            
        # Handle prefixes for icons
        is_claude_response = (icon == 'BLENDER')
        is_user_question = (icon == 'USER')
        
        # For Claude responses, we need to add the prefix if it doesn't have one
        if is_claude_response and not text.startswith("Claude:"):
            text = "Claude: " + text
        
        # For user questions, check if it already has a prefix
        if is_user_question and not text.startswith("You"):
            text = "You: " + text
            
        # Wrap text to fit the current panel width
        lines = self.wrap_text(text, region_width)
        
        # Create a box with enhanced style for better visual separation
        msg_box = layout.box()
        
        # Configure the message style based on who's speaking
        if is_claude_response:
            # Claude's responses get a slight blue tint
            msg_box.alert = False  # Regular color for Claude (blue in Blender's default theme)
            prefix_icon = 'BLENDER'
        else:
            # User questions get a slight emphasis
            msg_box.alert = False  # Regular color for user
            prefix_icon = icon
        
        # Draw each line with proper alignment and full width utilization
        first_line = True
        in_code_block = False
        code_box = None
        
        for i, line in enumerate(lines):
            # Handle empty lines
            if not line and not first_line:
                # Add an empty row for paragraph breaks (blank lines)
                msg_box.separator(factor=0.5)
                continue
            
            # Handle simplified code block markers
            if line.startswith("▼ Code Block Start ▼"):
                # Start a code block with special box
                code_box = msg_box.box()
                # Skip this line and continue
                continue
                
            elif line.startswith("▲ Code Block End ▲"):
                # End of code block
                code_box = None
                continue
                
            elif line.startswith("Language: ") and code_box:
                # Language header for code block
                header_row = code_box.row()
                header_row.alignment = 'CENTER'
                header_row.scale_y = 1.2
                header_row.label(text=line)
                continue
            
            # Format each line of text
            if code_box:
                # This is a line within a code block
                code_row = code_box.row()
                
                # Check for highlight markers (simplified)
                if line.startswith("➤ "):
                    # Highlighted line
                    col = code_row.column()
                    col.alert = True
                    col.label(text=line)
                elif line.startswith("⚠ "):
                    # Important line
                    col = code_row.column()
                    col.alert = True
                    col.scale_y = 1.2
                    col.label(text=line)
                else:
                    # Regular code line
                    code_row.label(text=line)
            else:
                # Regular text line (not in code block)
                row = msg_box.row()
                
                # First line gets the icon
                if first_line:
                    current_icon = prefix_icon if prefix_icon else 'NONE'
                    row.label(text=line, icon=current_icon)
                    first_line = False
                else:
                    # Indented continuation lines
                    indent_col = row.column()
                    indent_col.scale_x = 0.2
                    indent_col.label(text="")
                    
                    text_col = row.column()
                    text_col.scale_x = 1.0
                    text_col.alignment = 'EXPAND'
                    text_col.label(text=line)

# Register classes when outside of Blender
def register():
    """Register panel when outside of Blender"""
    pass

def unregister():
    """Unregister panel when outside of Blender"""
    pass

if __name__ == "__main__":
    register()