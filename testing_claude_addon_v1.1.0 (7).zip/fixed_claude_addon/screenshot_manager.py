"""
Screenshot management utilities for the Blender Claude addon
"""
import logging
import os
import glob

# Setup logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# Check if we're running inside Blender
try:
    import bpy
    BLENDER_AVAILABLE = True
except ImportError:
    BLENDER_AVAILABLE = False
    logger.warning("Running outside of Blender environment")

def get_screenshot_dir(context=None):
    """Get the directory where screenshots are stored, creating it if needed"""
    if not BLENDER_AVAILABLE or not context:
        # Default to current directory when not in Blender
        screenshot_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "screenshots")
    else:
        # Get the addon preferences
        addon_prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        # Check if there's a custom location defined 
        if addon_prefs.screenshot_location:
            screenshot_dir = addon_prefs.screenshot_location
        else:
            # Use the addon directory
            screenshot_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "screenshots")
    
    # Create the directory if it doesn't exist
    if not os.path.exists(screenshot_dir):
        try:
            os.makedirs(screenshot_dir, exist_ok=True)
            logger.info(f"Created screenshot directory: {screenshot_dir}")
        except Exception as e:
            logger.error(f"Failed to create screenshot directory: {str(e)}")
            # Fall back to the addon directory if we couldn't create the custom one
            if context and hasattr(context, 'preferences'):
                screenshot_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "screenshots")
                # Try to create this one too
                if not os.path.exists(screenshot_dir):
                    os.makedirs(screenshot_dir, exist_ok=True)
    
    return screenshot_dir

def get_all_screenshots(context=None):
    """Get a list of all screenshot files"""
    screenshot_dir = get_screenshot_dir(context)
    
    if not os.path.exists(screenshot_dir):
        return []
    
    # Get all PNG files in the directory
    screenshot_pattern = os.path.join(screenshot_dir, "claude_screenshot_*.png")
    screenshot_files = glob.glob(screenshot_pattern)
    
    return screenshot_files

def clear_all_screenshots(context=None):
    """Delete all cached screenshots"""
    screenshot_files = get_all_screenshots(context)
    removed_count = 0
    
    for file_path in screenshot_files:
        try:
            os.remove(file_path)
            removed_count += 1
            logger.info(f"Removed screenshot: {file_path}")
        except Exception as e:
            logger.error(f"Failed to remove screenshot {file_path}: {e}")
    
    return removed_count

def get_screenshots_size(context=None):
    """Get the total size of all screenshots in bytes"""
    screenshot_files = get_all_screenshots(context)
    total_size = 0
    
    for file_path in screenshot_files:
        try:
            total_size += os.path.getsize(file_path)
        except Exception as e:
            logger.error(f"Failed to get size of {file_path}: {e}")
    
    return total_size

def format_size(size_bytes):
    """Format bytes to a human-readable format"""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.2f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.2f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"

def get_formatted_screenshot_size(context=None):
    """Get the formatted size of all screenshots"""
    total_size = get_screenshots_size(context)
    return format_size(total_size)

if __name__ == "__main__":
    # Test functionality when run directly
    if BLENDER_AVAILABLE:
        screenshots = get_all_screenshots(bpy.context)
        print(f"Found {len(screenshots)} screenshots")
        print(f"Total size: {get_formatted_screenshot_size(bpy.context)}")
    else:
        print("Running outside Blender")
        screenshots = get_all_screenshots()
        print(f"Found {len(screenshots)} screenshots")
        print(f"Total size: {get_formatted_screenshot_size()}")
